import java.util.Scanner;

import College.Record;
import College.StudentRecordManagement;

public class StudentRecordLinkedList  {

	public static void main(String[] args) {
		
		System.out.println("\t\t\tWelcome to Student Management System !!");
		StudentRecordManagement hr = new StudentRecordManagement();

		Record record = new Record();
    
        // Initial Employee record
        // Using mutators to had code the data
        record.setIdNumber(6862);
    record.setContactNumber(911);
    record.setName("Ankit");

    // Calling add() record method to
    // add static data/(Hard CodedData) to linked List
    hr.add(record);

    // Creating Scanner Object to read input
    Scanner input = new Scanner(System.in);

    // Creating option integer variable
    int option = 0;

    // Do - While loop
    do {
        menu();
        option = input.nextInt();

        // Switch case
        switch (option) {

        // Case 1
        case 1:

            // Display message
            System.out.print("Enter Student ID Number: ");

            int idNumber = input.nextInt();

            // Display message
            System.out.print("Enter Student Contact Number: ");

            int contactNumber = input.nextInt();
            input.nextLine();

            // Display message
            System.out.print("Enter Student Name: ");

            String name = input.nextLine();

            // Create record object and pass constructor
            // parameters.
            record = new Record(name, idNumber,
                                contactNumber);
            // Call add() record
            hr.add(record);
            System.out.println("");
            System.out.println(record.toString());
            System.out.println("Record Added Successfully..");
            System.out.println("");

            
            break;

        // Case 2
        case 2:

            // Display message
        	System.out.print("Enter Student ID Number for Deleting the Record: ");
            int rId = input.nextInt();

            // Invoke remove/delete record
            hr.delete(rId);

            break;

        // Case 3
        case 3:

            // Display message
        	System.out.print("Enter Student ID Number for Updating the Record: ");

            int rIdNo = input.nextInt();
            hr.update(rIdNo, input);
            break;

        // Case 4
        case 4:

            // Display message
        	System.out.print("Enter Student ID Number for Searching the Record: ");
            int bookId = input.nextInt();

            if (!hr.find(bookId)) {
                System.out.println("Student id does not exist\n");
            }

            break;

        // Case 5
        case 5:
        	System.out.println("");
            hr.display();
            System.out.println("");
            break;

        // Case 6
        case 6:

        	System.out.println("Please visit again..." + "Have a nice day!!");
        	System.out.println("");
			 System.exit(0);
        	break;

        // Case 7: Default case
        // If none above case executes
        default:

        	System.out.println("Invalid Option...");
    		System.out.println("Try Again...");
    		System.out.println("");
    		
    		break;
        }
    }

    // Checking condition
    while (option != 6);
}

// Method 2
// Menu - Static menu for displaying options
public static void menu()
{

    // Printing statements displaying menu on console
    System.out.println("MENU");
    System.out.println("");
    System.out.println("1: Add Student");
    System.out.println("2: Delete Student");
    System.out.println("3: Update Student");
    System.out.println("4: Search Student");
    System.out.println("5: Display Students");
    System.out.println("6: Exit program");
    System.out.println("");
    System.out.print("Enter your Choice: ");
}

}
