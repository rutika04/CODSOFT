import java.util.Scanner;

public class gradecalculator {

	public static void main(String[] args) {
		
		  String grade;
		  //Input Marks
		  Scanner myObj = new Scanner(System.in);
		  System.out.println("Enter Obtained Marks of C Programming: ");
		  int cmarksa = myObj.nextInt();
		  System.out.println("Enter Obtained Marks of C++ Programming: ");
		  int cppmarks = myObj.nextInt();
		  System.out.println("Enter Obtained Marks of Java Programming: ");
		  int javamarks = myObj.nextInt();
		  System.out.println("Enter Obtained Marks of Python Programming: ");
		  int pythonmarks = myObj.nextInt();
		  System.out.println("Enter Obtained Marks of Machine Learning: ");
		  int mlmarks = myObj.nextInt();
		  System.out.println("Enter Obtained Marks of JavaScript: ");
		  int javasmarks = myObj.nextInt();
		  
		  //Total of Marks
		  int total = cmarksa + cppmarks + javamarks + pythonmarks + mlmarks + javasmarks;
		  
		  //Average Marks
		  double average = (double)total /6;
		  
		  //Assign Grades
		  if(average >=80) {
			   grade = "A" + "\nExcellent!!";
		  }
		  else if(average>=60 && average<80) {
			   grade = "B" +"\nVery Good.";
		  }
		  else if(average>=40 && average<60) {
			  grade = "C" + "Well Done.";
		  }
		  else {
			  grade = "D " + "You are Fail...";
			  
		  }
		  
		  //Display All
		  System.out.println("Your Total Marks Obtained are: " + total);
		  System.out.println("Your Average Percentage are: " + average);
		  System.out.println("Your Grade is: " + grade);

	}

}
