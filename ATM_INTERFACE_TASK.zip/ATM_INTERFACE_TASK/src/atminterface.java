import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class atminterface {
	
	public atminterface() {
		try {
			
			System.out.println("Welcome to Automated Teller Machine....");
		 int balance = 0, withdraw, deposit;
		 
		 int Choice = -1;
         BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
         
         Scanner scanner = new Scanner(System.in);
         
       //Get the Choice from User
		 
		 do {
			 System.out.println("Choose 1 for Deposit");
			 System.out.println("Choose 2 for Check the Balance");
			 System.out.println("Choose 3 for Withdraw");
			 System.out.println("Choose 4 for Exit");
			 System.out.println("Enter the Choice Number you want to perform task : ");
			 
			 Choice = Integer.parseInt(br.readLine());
			 
			 //Perform operation by user's choice
			 
			 switch(Choice){
				 case 1:
					 //Deposit the amount
					 System.out.println("Remember: For deposit, your amount must be more than rs. 100");
					 System .out.println("Enter Amount for Deposit:");
					 deposit = scanner.nextInt();
					 
					 if(deposit >=100) {
						 balance = balance+deposit;
						 System.out.println("Your Money has been successfully deposited.");
						 System.out.println(""); 
					 }
					 else {
						 System.out.println("Sorry, you can't deposit below rs.100");
						 System.out.println("Please deposit minimum rs. 100");
						 System.out.println("");
					 }
					 break;
					 
				 case 2:
					 //View Balance
					 System.out.println("Your Balance is:" + balance);
					 System.out.println("");
					 break;
					 
				 case 3:
					 //Withdraw the amount
					 System.out.println("Remember: You have some limitations for withdraw the amount.");
					 System.out.println("For withdraw your balance must be more than rs. 500");
					 
					 
					 if(balance <=500 ) {
						 System.out.println("Sorry..Insufficient Balance" + "\nYou can't withdraw amount");
						 System.out.println("");
						 
					 }
					 else if(balance <=5000 && balance > 500) {
						 System.out.println("Enter Amount for withdraw:");
						 withdraw = scanner.nextInt();
						 if(withdraw >= balance) {
							 System.out.println("Sorry..Insufficient Balance" + "\nYou can't withdraw amount");
							 System.out.println("");
						 }
						 else if(withdraw <=4500 && withdraw >=500) {
							 balance = balance - withdraw;
							 System.out.println("Please collect your money");
							 System.out.println("Your Money has been successfully withdrawn...");
							 System.out.println("Please visit again." + "Have a nice day!!");
							 System.out.println("");
							 
						 }
						 else {
							 System.out.println("Sorry...");
							 System.out.println("Please enter amount for withdraw in between rs.500 to rs. 4500");
							 System.out.println("");
						 }
						 						 
					 }
					 
					 else if(balance <=50000 && balance >5000) {
						 System.out.println("Enter Amount for withdraw:");
						 withdraw = scanner.nextInt();
						 if(withdraw >= balance) {
							 System.out.println("Sorry..Insufficient Balance" + "\nYou can't withdraw amount");
							 System.out.println("");
						 }
						 else if(withdraw <=40000 && withdraw >=5000) {							 
							 balance = balance - withdraw;
							 System.out.println("Please collect your money");
							 System.out.println("Your Money has been successfully withdrawn...");
							 System.out.println("Please visit again." + "Have a nice day!!");
							 System.out.println("");
						 }
						 else {
							 System.out.println("Sorry...");
							 System.out.println("Please enter amount for withdraw in between rs.5000 to rs. 40000");
							 System.out.println("");
						 }
					 }
					 
					 else if(balance <= 500000 && balance >50000) {
						 System.out.println("Enter Amount for withdraw:");
						 withdraw = scanner.nextInt();
						 
						 if(withdraw >= balance) {
							 System.out.println("Sorry..Insufficient Balance" + "\nYou can't withdraw amount");
							 System.out.println("");
						 }
						 else if(withdraw <=495000 && withdraw >=50000) {
							 balance = balance - withdraw;
							 System.out.println("Please collect your money");
							 System.out.println("Your Money has been successfully withdrawn...");
							 System.out.println("Please visit again." + "Have a nice day!!");
							 System.out.println("");
						 }
						 else {
							 System.out.println("Sorry...");
							 System.out.println("Please enter amount for withdraw in between rs.50000 to rs. 500000");
							 System.out.println("");
						 }
					 }
					 
					 else if(balance <= 50000000 && balance >500000) {
						 System.out.println("Enter Amount for withdraw:");
						 withdraw = scanner.nextInt();
						 if(withdraw >= balance) {
							 System.out.println("Sorry..Insufficient Balance" + "\nYou can't withdraw amount");
							 System.out.println("");
						 }
						 else if(withdraw <=40000000 && withdraw >=500000) {
							 balance = balance - withdraw;
							 System.out.println("Please collect your money");
							 System.out.println("Your Money has been successfully withdrawn...");
							 System.out.println("Please visit again." + "Have a nice day!!");
							 System.out.println("");
						 }
						 else {
							 System.out.println("Sorry...");
							 System.out.println("Please enter amount for withdraw in between rs.500000 to rs. 50000000");
							 System.out.println("");
						 }
					 }
					 else {
						 System.out.println("Above the rs. 50000000 you need to submit your statement in your bank.");
						 System.out.println("Please visit again." + "Have a nice day!!");
						 System.out.println("");
					 }
					 
					 break;
				 case 4:
					 System.out.println("Please visit again..." + "Have a nice day!!");
					 System.out.println("");
					 System.exit(0);
					 break;
           	  default :
              	  System.out.println("Invalid Option...");
              	  System.out.println("Try Again...");
              	  System.out.println("");
              	
			 }
			 
		 } while (Choice !=0);
		 
		} catch (Exception e) {

      	  // TODO: handle exception
      	  e.printStackTrace();
        }
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new atminterface();

	}

}
