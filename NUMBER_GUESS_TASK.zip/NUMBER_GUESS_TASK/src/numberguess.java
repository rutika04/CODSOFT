import java.util.Random;
import java.util.Scanner;

public class numberguess {

	public static void main(String[] args) {
		
		//create random number
		Random Random_number= new Random();
	    int right_guess=Random_number.nextInt(100);
	    int turns=0;
	    Scanner scan=new Scanner(System.in);
	    System.out.println("Guess a number between 1 to 100, You will have 06 Attempts!" + "\nBest of luck!" );
	    
	    int guess;
	    int i=0;
	    boolean win=false;
	    while(win==false) {
	      guess=scan.nextInt();
	      turns++;
	    
	      
	    //Allow the attempts
	    if(guess==right_guess) {
	      win=true;
	    }
	    else if(i>4){
	      System.out.println("You loose! the right answer was: "+right_guess);
	      System.out.println("Try Again...");
	      return;
	    }
	    else if(guess<right_guess){
	      i++;
	      System.out.println("Yor Guess is Lower Than the Right Guess! Attempts Left: "+(5-i));
	      
	      
	      
	    }
	    else if(guess>right_guess) {
	      i++;
	      System.out.println("Your Guess is Higher Than the Right Guess! Attempts Left: "+(5-i));
	      
	    }
	    
	    
	  }
	    //Display Status
	    System.out.println("You win!");
	    System.out.println("The number was "+right_guess);
	    System.out.println("You used "+turns+" Attempts to guess the right number");
	    if (turns <=6) {
	    	System.out.println("Your score is "+((turns)*10)+" out of 100 \nCongratulations!!!\nPlay Again");
	    }
	    else {
	    	System.out.println("Your score is "+((turns)*5)+" out of 100 \nCongratulations!!!\nPlay Again");
	    }
	    
	}

}
