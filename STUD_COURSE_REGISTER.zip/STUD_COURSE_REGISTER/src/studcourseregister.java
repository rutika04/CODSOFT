import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;
public class studcourseregister {
	
	public studcourseregister() {
		try {
			
			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");//Loading Driver
			Connection connection= DriverManager.getConnection("jdbc:ucanaccess://G:\\Rutika\\ECLIPSE_LAB\\STUD_COURSE_REGISTER\\Database11.accdb");//Establishing Connection
			System.out.println("Welcome to Student Course Registration System !!");
			System.out.println("");
			
			int capacity = 25;
			int capacity1 = 25;
			int capacity2 = 25;
			int Choice = -1;

            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            
          //Get the Choice from User
            do {
            	System.out.println("1. Add New Student");
            	System.out.println("2. Register New Course");
            	System.out.println("3. Delete your Course");
            	System.out.println("4. View All Courses");
            	System.out.println("5. View Student List");
            	System.out.println("6. View Courses and Capacity");
            	System.out.println("7. Exit");
            	
            	System.out.println("Enter your Choice: ");
            	System.out.println("");
            	Choice = Integer.parseInt(br.readLine());
            	
   			 //Perform operation by user's choice
            	
            	switch(Choice) {
            	case 1:
            		//Add New Student
            		Scanner scanner = new Scanner(System.in);
            		System.out.println("Enter ID:");
            		String id = scanner.nextLine();
            		int idd = Integer.parseInt(id);
            		
            		String query1 = "SELECT StdID FROM StudentTable WHERE StdID = ?";
            		PreparedStatement ps = connection.prepareStatement(query1);
            		ps.setInt(1,idd);
            		ResultSet resultset = ps.executeQuery() ;
            		
            		if(resultset.next()) {
            			System.out.println("This ID is already exists here.");
            			System.out.println("Please Check Existed Student ID's. ");
            			System.out.println("");
            		}
            		else {
            			System.out.println("Enter Student Name:");
                		String name = scanner.nextLine();
            			
            			String insertQuery = "INSERT INTO StudentTable(StdID, StdName) VALUES(?,?)";
                		PreparedStatement insertps=connection.prepareStatement(insertQuery);
                		insertps.setInt(1,idd);
                		insertps.setString(2,name);
                		
                		System.out.println("Student Added Successfully...");
                		System.out.println("");
                		insertps.executeUpdate();
                		insertps.close();
            		}
            		ps.close();
            		resultset.close();
            		break;
            	case 2:
            		//Register Course
            		System.out.println("Enter the Student id to Identify the record to register new course: ");
            		int i = Integer.parseInt(br.readLine());
            		Scanner sc = new Scanner(System.in);
            		System.out.println("Enter Your Name:");
            		String m_name2 = sc.nextLine();
            		System.out.println("");
            		
            		String query2 = "SELECT * FROM StudentTable WHERE StdID = ? AND RegisteredCourses IS NOT NULL";
            		PreparedStatement viewquery = connection.prepareStatement(query2);
            		viewquery.setInt(1,i);
            		ResultSet resultset1 = viewquery.executeQuery() ;
            		
            		if(resultset1.next()) {
            			String assignedCourse = resultset1.getString("RegisteredCourses");
                        System.out.println("You are already assigned for the course: " + assignedCourse);
                        System.out.println("");
            		}
            		else {
            			Set<String> validCourseNames = new HashSet<>(Arrays.asList("C Programming", "JAVA Programming", "Python for Machine Learning"));
            			
            			System.out.println("Enter Course Name:");
                		String m_course2 = sc.nextLine();
                		System.out.println("");
                		if(validCourseNames.contains(m_course2)) {
                			String query3 = "SELECT Capacity FROM CourseTable WHERE CourseName = ?";
                    		PreparedStatement ps1 = connection.prepareStatement(query3);
                    		ps1.setString(1,m_course2);
                    		
                    		ResultSet resultset2 = ps1.executeQuery() ;
                    		while (resultset2.next()) {
                    			int colval = resultset2.getInt("Capacity");
                    			if(colval <=25 && colval >=1) {
                    				String updatequery = "UPDATE StudentTable SET StdName = ?, RegisteredCourses = ? WHERE StdID=?";
                    				if(m_course2.equalsIgnoreCase("C Programming")) {
                    					capacity--;
                            			String updatequery1 = "UPDATE CourseTable SET Capacity =? WHERE CourseName = 'C Programming'";
                            			PreparedStatement ps2 = connection.prepareStatement(updatequery1);
                            			ps2.setInt(1,capacity);
                            			ps2.executeUpdate();
                            			ps2.close();
                            			System.out.println("Course Assigned Successfully...");
                            			System.out.println("");
                    				}
                    				else if(m_course2.equalsIgnoreCase("Java Programming")) {
                            			String updatequery2 = "UPDATE CourseTable SET Capacity =? WHERE CourseName = 'JAVA Programming'";
                            			capacity1--;
                            			PreparedStatement ps3 = connection.prepareStatement(updatequery2);
                            			ps3.setInt(1,capacity1);
                            			ps3.executeUpdate();
                            			ps3.close();
                            			System.out.println("Course Assigned Successfully...!!");
                            			System.out.println("");
                    				}
                    				else if(m_course2.equalsIgnoreCase("Python for Machine Learning")) {
                    					String updatequery3 = "UPDATE CourseTable SET Capacity = ? WHERE CourseName = 'Python for Machine Learning'";
                    					capacity2--;
                    					PreparedStatement ps4 = connection.prepareStatement(updatequery3);
                    					ps4.setInt(1,capacity2);
                    					ps4.executeUpdate();
                    					ps4.close();
                    					System.out.println("Course Assigned Successfully...!!!");
                    					System.out.println("");
                    				}
                    				PreparedStatement ps5 = connection.prepareStatement(updatequery);
                            		ps5.setInt(3,i);
                            		ps5.setString(1,m_name2);
                            		ps5.setString(2,m_course2);
                            		ps5.executeUpdate();
                    			}
                    			else {
                    				System.out.println("Sorry....Seats are Not available for this Course...");
                        			System.out.println("");
                    			}
                    		}
                    		ps1.close();
                    		resultset2.close();
                		}
                		else {
                			System.out.println("Invalid Course Name");
                			System.out.println("Please Enter Correct Course Name");
                			System.out.println("");
                		}
            		}
            		viewquery.close();
            		resultset1.close();	
            		break;
            	case 3:
            		//Remove or Delete the Recorded Course
            		System.out.println("Enter the Student id to identify the record to remove the course:");
            		int integer = Integer.parseInt(br.readLine());
            		Scanner sc1 = new Scanner(System.in);
            		System.out.println("Enter your Course Name for removing:");
            		String rem_course = sc1.nextLine();
            		System.out.println("");
            		
            		String dltquery = "UPDATE StudentTable SET RegisteredCourses = NULL WHERE StdID = ?";
            		PreparedStatement psdlt3 = connection.prepareStatement(dltquery);
            		psdlt3.setInt(1, integer);
            		int deleterows = psdlt3.executeUpdate();
            		if(deleterows >0) {
                		if(rem_course.equalsIgnoreCase("C Programming")) {
                			capacity++;
                			String update1 = "UPDATE CourseTable SET Capacity = ? WHERE CourseName = 'C Programming'";
                			PreparedStatement psdlt = connection.prepareStatement(update1);
                			psdlt.setInt(1, capacity);
                			psdlt.executeUpdate();
                			System.out.println("Course Removed Successfully...");
                			System.out.println("");
                			psdlt.close();
                		}	
                		else if(rem_course.equalsIgnoreCase("Java Programming")) {
                			capacity++;
                			String update2 = "UPDATE CourseTable SET Capacity = ? WHERE CourseName = 'Java Programming'";
                			PreparedStatement psdlt1 = connection.prepareStatement(update2);
                			psdlt1.setInt(1, capacity);
                			psdlt1.executeUpdate();
                			System.out.println("Course Removed Successfully...");
                			System.out.println("");
                			psdlt1.close();
                		}
                		else if(rem_course.equalsIgnoreCase("Python for Machine Learning")) {
                			capacity++;
                			String update3 = "UPDATE CourseTable SET Capacity = ? WHERE CourseName = 'Python for Machine Learning'";
                			PreparedStatement psdlt2 = connection.prepareStatement(update3);
                			psdlt2.setInt(1, capacity);
                			psdlt2.executeUpdate();
                			System.out.println("Course Removed Successfully...");
                			System.out.println("");
                			psdlt2.close();
                		}
                		else {
                			System.out.println("Please Enter Your Correct Course Name...");
                			System.out.println("");
                		}
            		}
            		else {
            			System.out.println("No matching records found for removal.");
            		}
            		psdlt3.close();
            		break;
            	case 4:
            		//Display Information of All Courses
            		PreparedStatement viewed1 = connection.prepareStatement("SELECT * FROM CourseTable");
            		ResultSet rs1 = viewed1.executeQuery();
            		System.out.println("Course ID:\t\tCourse Name:\t\tCourse Information:\t\tCapacity:\tSchedule");
            		while(rs1.next()) {
            			int no2 = rs1.getInt("CourseCode");
            			String nm2 = rs1.getString("CourseName");
            			String nm3 = rs1.getString("AboutCourse");
            			int no3 = rs1.getInt("Capacity");
            			String nm4 = rs1.getString("Schedule");
            			System.out.println(no2 + ":\t\t" + nm2 + ":\t\t" + nm3 + ":\t" + no3);
            			System.out.println("");
            		}
            		viewed1.close();
        			rs1.close();
            		break;
            	case 5:
            		//Display Student List
            		PreparedStatement viewed2 = connection.prepareStatement("SELECT * FROM StudentTable");
            		ResultSet rs2 = viewed2.executeQuery();
            		System.out.println("Student ID:\t\tStudent Name");
            		while(rs2.next()) {
            			int no1 = rs2.getInt("StdID");
            			String nm1 = rs2.getString("StdName");
            			System.out.println(no1 + "\t\t" + nm1);
            			System.out.println("");
            		}
            		viewed2.close();
        			rs2.close();
            		break;
            	case 6:
            		//Display Course Name and Available Seats
            		String query4 = "SELECT * FROM CourseTable";
            		PreparedStatement ps7 = connection.prepareStatement(query4);
            		ResultSet resultset3 = ps7.executeQuery() ;
            		System.out.println("Course Name:\tCapacity");
            		while(resultset3.next()) {
            			String coursenm = resultset3.getString("CourseName");
            			int colval = resultset3.getInt("Capacity");
            			System.out.println(coursenm +":\t" + colval);
            			System.out.println("");
            		}
            		ps7.close();
        			resultset3.close();
            		break;
            	case 7:
            		//Exit
            		connection.close();
            		System.out.println("Please visit again..." + "Have a nice day!!");
            		System.out.println("");
					 System.exit(0);
					 break;
            		default:
            		System.out.println("Invalid Option...");
            		System.out.println("Try Again...");
            		System.out.println("");
            		connection.close();
            	}
            } while(Choice !=0);
		} catch (Exception e) {

      	  // TODO: handle exception
      	  e.printStackTrace();
        }
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new studcourseregister();

	}

}